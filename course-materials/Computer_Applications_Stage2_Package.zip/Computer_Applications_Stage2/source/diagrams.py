from pathlib import Path
from html import escape as E
ROOT=Path(__file__).resolve().parents[1]
IMG=ROOT/'Computer_Applications_Stage2_Images'
NAVY='#142d4e'; BLUE='#2878ac'; GOLD='#b99445'; PALE='#edf5fa'
def text(x,y,t,size=22,color=NAVY,weight='normal'):
 return f'<text x="{x}" y="{y}" text-anchor="middle" direction="rtl" unicode-bidi="plaintext" font-size="{size}" fill="{color}" font-weight="{weight}">{E(t)}</text>'
def rect(x,y,w,h,fill=PALE,stroke=BLUE):
 return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{fill}" stroke="{stroke}" stroke-width="2"/>'
def box(x,y,w,h,a,b=''):
 return rect(x,y,w,h)+text(x+w/2,y+h/2-5,a,24,weight='bold')+text(x+w/2,y+h/2+32,b,18)
def arrow(x1,y1,x2,y2):
 return f'<path d="M{x1} {y1} L{x2} {y2}" fill="none" stroke="{GOLD}" stroke-width="5" marker-end="url(#arrow)"/>'
def svg(name,title,body,caption='رسم تعليمي أصلي • ليس لقطة شاشة لبرنامج'):
 s=f'''<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="620" viewBox="0 0 1200 620"><defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0,0 L0,6 L9,3 z" fill="{GOLD}"/></marker></defs><rect width="1200" height="620" fill="white"/><g font-family="Noto Sans Arabic,DejaVu Sans">{text(600,55,title,30,weight='bold')}{body}{text(600,598,caption,16)}</g></svg>'''
 (IMG/f'{name}.svg').write_text(s)
def flow(name,title,labels,footer):
 body=''
 xs=[880,590,300,10] if len(labels)==4 else [840,440,40]
 w=270 if len(labels)==4 else 320
 for i,((a,b),x) in enumerate(zip(labels,xs)):
  body+=box(x,170,w,160,a,b)
  if i<len(labels)-1:body+=arrow(x-10,250,x-35,250)
 body+=text(600,420,footer,24)
 svg(name,title,body)
flow('internet','من السؤال إلى معلومة موثوقة',[('سؤال واضح','موضوع • زمن • جهة'),('بحث دقيق','كلمات ومعاملات'),('تقويم المصدر','ناشر • تاريخ • دليل')],'المتصفح يعرض الصفحات؛ محرك البحث يساعد على العثور عليها')
flow('email_flow','رحلة البريد الإلكتروني',[('المرسل','إنشاء الرسالة'),('خادم الإرسال','SMTP'),('خادم الاستقبال','DNS / MX ثم تسليم'),('المستقبل','Webmail / IMAP')],'الجزء المحلي  student  │  الفاصل  @  │  النطاق  example.edu')
body=rect(40,100,1120,420)+rect(40,100,1120,60,NAVY,NAVY)+text(600,140,'واجهة بريد مبسطة — Outlook / Gmail',24,'white')
for y,a,b in [(205,'إلى To','student@example.edu'),(270,'الموضوع Subject','تطبيقات الحاسوب — واجب 2'),(345,'المتن Body','تحية • غرض واضح • توقيع')]:
 body+=text(1030,y,a,20)+text(530,y,b,24)
body+=box(80,410,250,75,'إرسال Send','')+text(730,460,'مرفق Attachment  │  واجب.xlsx',24)
svg('mail_ui','عناصر نافذة إنشاء رسالة — مخطط إرشادي',body)
body=rect(40,100,1120,430)+rect(40,100,1120,75,NAVY,NAVY)+text(600,147,'File  │  Home  │  Insert  │  Design  │  Animations  │  Slide Show',24,'white')
body+=rect(955,190,180,300)+text(1045,240,'المصغرات',22)+text(1045,280,'Thumbnails',17)
body+=rect(95,190,820,260,'#ffffff')+text(505,275,'مساحة تحرير الشريحة',30)+text(505,320,'Slide Canvas',23)
body+=rect(95,465,820,50)+text(505,499,'ملاحظات المتحدث Notes',19)
svg('ppt_ui','مناطق PowerPoint — رسم تخطيطي لا لقطة واجهة',body)
body=rect(70,100,1060,440,'#ffffff')+text(600,160,'رسالة واحدة واضحة في العنوان',34,weight='bold')
body+=box(650,200,420,220,'مخطط أو مثال كبير','المرئي يفسر الفكرة')+box(130,200,440,220,'نص قصير قابل للقراءة','التفصيل في الملزمة والملاحظات')
body+=text(600,500,'مساحة بيضاء • تباين واضح • مصدر أو وحدة قياس',24)
svg('slide_parts','تشريح شريحة تعليمية',body)
flow('animation','التوقيت يخدم خطوات التفكير',[('المدخلات','On Click'),('العملية','On Click'),('النتيجة','After Previous')],'Transition بين الشرائح │ Animation داخل الشريحة')
flow('presentation','دورة إعداد العرض وتسليمه',[('تأليف','هدف وبنية'),('اختبار','قراءة ووسائط'),('نشر','PPTX + PDF')],'يُختبر الملف من مجلد التسليم وعلى جهاز العرض')
body=''
for c in range(5):
 for r in range(6):
  x=170+c*170;y=110+r*66
  fill=BLUE if c==0 or r==0 else ('#fff0ca' if c==2 and r==3 else PALE)
  body+=rect(x,y,165,61,fill, '#ffffff')
  label=chr(64+c) if r==0 and c else (str(r) if c==0 and r else ('B3' if c==2 and r==3 else ''))
  body+=text(x+82,y+41,label,24,'white' if c==0 or r==0 else NAVY)
body+=text(600,555,'B3 = العمود B ∩ الصف 3     │     A2:C5 نطاق مستطيل',24)
svg('excel_grid','الخلية والصف والعمود والنطاق',body)
flow('formatting','نقل المحتوى وتنسيق عرضه',[('المحتوى','قيمة أو صيغة'),('اللصق المختار','Values / Formulas'),('الشكل','Font / Alignment')],'Wrap Text يُظهر النص؛ Merge يغير بنية الخلايا')
body=box(830,170,300,160,'القيمة المخزنة','0.15')+arrow(810,250,760,250)+box(410,170,330,160,'تنسيق Percentage','15%')+box(50,170,300,160,'العدد نفسه','لم تتغير القيمة')
body+=text(600,430,'تنسيق منزلتين لا يعادل استخدام ROUND في الحساب',25)
svg('number_formats','القيمة وطريقة عرضها',body)
flow('sheet_tools','قبل تغيير بنية ورقة العمل',[('نسخة محفوظة','حماية العمل'),('تحديد صحيح','خلية / صف / عمود'),('تحقق بعد التنفيذ','علاقة السجل وصيغه')],'إخفاء البيانات لا يحمي سريتها؛ حماية الورقة ليست تشفيرًا')
body=box(800,135,330,130,'B2 × C2','4 × 2500 = 10000')+box(400,135,330,130,'D2 × $F$1','10000 × 10% = 1000')+box(30,135,300,130,'D2 + E2','11000')
body+=arrow(785,200,745,200)+arrow(385,200,345,200)+text(600,370,'مرجع نسبي: D2 → D3 عند النسخ إلى الصف التالي',26)+text(600,430,'مرجع مطلق: $F$1 يبقى ثابتًا',26)
svg('formula','فاتورة محلولة ومراجع الخلايا',body)
body=box(820,130,310,130,'درجة الطالب','B2 = 50')+box(420,130,320,130,'اختبار منطقي','B2 >= 50')+arrow(800,195,755,195)
body+=arrow(420,235,330,360)+arrow(570,265,570,360)+box(80,375,320,110,'صحيح: ناجح','القيمة 50 مشمولة')+box(500,375,360,110,'خطأ: راسب','مثل الدرجة 49')
svg('functions','كيف تختار IF أحد فرعين؟',body)
flow('lookup','البحث بمفتاح فريد',[('الرمز','102'),('جدول المرجع','101 أمل │ 102 نور'),('النتيجة','نور')],'XLOOKUP أو VLOOKUP مع مطابقة تامة؛ اختبر رمزًا غير موجود')
flow('data_tools','أدوات لا تؤدي العمل نفسه',[('Sort','تغيير الترتيب'),('Filter','إخفاء غير المطابق'),('Validation','تقييد الإدخال')],'Remove Duplicates يحذف سجلات؛ احفظ نسخة وحدد معنى التكرار')
body=''
for i,(label,val) in enumerate([('قرطاسية',30),('نقل',20),('صيانة',50)]):
 x=230+i*280;h=val*5
 body+=rect(x,440-h,150,h,BLUE,BLUE)+text(x+75,475,label,23)+text(x+75,420-h,str(val)+' ألف',22)
body+=f'<path d="M150 130 L150 440 L1080 440" fill="none" stroke="{NAVY}" stroke-width="3"/>'+text(620,550,'المجموع 100 ألف │ وحدة القياس ضرورية لفهم الرسم',24)
svg('charts','مصروفات ثلاث فئات — مثال بيانات اصطناعية',body)
flow('review','استيراد قابل للمراجعة',[('المصدر','CSV / Excel / Access'),('التحويل','ترميز وأنواع وأسماء'),('التحقق','عدد ومفاتيح ومجاميع')],'Freeze Panes للرؤوس؛ Split لأجزاء عرض مستقلة')
flow('data_info','من بيانات خام إلى معلومات',[('بيانات Data','40، 50، 70، 80'),('معالجة Processing','شرط نجاح >= 50'),('معلومات Information','3 ناجحين من 4')],'قاعدة البيانات تنظم الحقائق والعلاقات؛ الاستعلام يجيب عن السؤال')
body=box(830,140,310,250,'Students','StudentID [PK]')+text(985,305,'StudentName',23)+box(435,140,320,310,'Enrollments','EnrollmentID [PK]')
body+=text(595,300,'StudentID [FK]',23)+text(595,340,'CourseID [FK]',23)+text(595,385,'Grade',23)
body+=box(45,140,310,250,'Courses','CourseID [PK]')+text(200,305,'CourseName',23)
body+=arrow(820,260,770,260)+arrow(365,260,420,260)+text(795,215,'1 : ∞',22)+text(385,215,'1 : ∞',22)+text(600,530,'طلاب ↔ مقررات: علاقة متعدد إلى متعدد عبر جدول التسجيلات',24)
svg('relationships','المفاتيح والعلاقات والتكامل المرجعي',body)
flow('query','الاستعلام لا يحذف البيانات المستبعدة',[('المصدر','40 │ 50 │ 70 │ 80'),('WHERE','Grade >= 50'),('النتيجة','50 │ 70 │ 80')],'ORDER BY Grade DESC يعيد 80، 70، 50')
flow('form_report','أدوار كائنات Access',[('Form','واجهة إدخال'),('Table / Query','تخزين واسترجاع'),('Report','عرض وطباعة')],'عنصر غير مرتبط لا يحفظ تلقائيًا في حقل بمجرد ظهوره')
flow('import_export','الاستيراد والربط والتصدير',[('Import','نسخة داخل الوجهة'),('Link','اعتماد على المصدر'),('Export','ملف ناتج للتحقق')],'تحقق من السجلات والأنواع والعينات والمجموع؛ لا يكفي اكتمال المعالج')
flow('project','مسار مشروع متكامل',[('Access','بيانات وعلاقات'),('Excel','تحليل وتحقق'),('PowerPoint','تفسير وتوصية')],'بريد مهني للتسليم │ البيانات الافتراضية: 12 سجلًا، مجموعها 360000')
flow('assessment','أدلة نجاح المشروع',[('تصميم','متطلبات ومفاتيح'),('تنفيذ','صيغ واستعلامات'),('تحقق','اختبارات ومناقشة')],'يُقيّم المنطق والدقة والتوثيق قبل الزخرفة')
print('SVG diagrams:',len(list(IMG.glob('*.svg'))))
