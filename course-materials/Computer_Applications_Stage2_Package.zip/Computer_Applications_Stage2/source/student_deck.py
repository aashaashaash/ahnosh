from pathlib import Path
import json,re
from pptx import Presentation
from pptx.util import Inches,Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN,MSO_ANCHOR,MSO_AUTO_SIZE
from pptx.oxml.xmlchemy import OxmlElement
from PIL import ImageFont
from content import L,AUTHOR
from student_content import C,EX
ROOT=Path(__file__).resolve().parents[1];IMG=ROOT/'Computer_Applications_Stage2_Images'
FONTS={}
R=Presentation();R.slide_width=Inches(13.333);R.slide_height=Inches(7.5)
R.core_properties.title='تطبيقات الحاسوب — عرض المحاضرات للطلاب';R.core_properties.author=AUTHOR
N='142D4E';B='2878AC';G='B99445';P='EDF5FA';W='FFFFFF';M='52677D'
FONT='Noto Sans Arabic';MAN=[];MEASURES=[]
def box(sl,x,y,w,h,color,line=None):
 sh=sl.shapes.add_shape(1,Inches(x),Inches(y),Inches(w),Inches(h));sh.fill.solid();sh.fill.fore_color.rgb=RGBColor.from_string(color)
 if line:sh.line.color.rgb=RGBColor.from_string(line)
 else:sh.line.fill.background()
 return sh

def text(sl,x,y,w,h,txt,size=26,color=N,bold=False,center=False):
 # Font-aware wrapping check, with a lower bound suitable for classroom display.
 def lines(sz):
  key=(bold,sz)
  if key not in FONTS:FONTS[key]=ImageFont.truetype('/usr/share/fonts/truetype/noto/NotoSansArabic-'+('Bold' if bold else 'Regular')+'.ttf',round(sz*96/72))
  f=FONTS[key]
  num=0
  for row in txt.split('\n'):
   num+=1;line=''
   for word in row.split():
    v=(line+' '+word).strip()
    if f.getlength(v)>(w-.16)*96 and line:num+=1;line=word
    else:line=v
  return num
 while lines(size)*size/72*1.65>h-.02 and size>23:size-=1
 MEASURES.append(dict(slide=len(R.slides),text=txt[:90],size=size,estimated=round(lines(size)*size/72*1.65,2),height=h))
 sh=sl.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=sh.text_frame;tf.clear();tf.word_wrap=True;tf.vertical_anchor=MSO_ANCHOR.TOP;tf.auto_size=MSO_AUTO_SIZE.NONE
 tf.margin_left=tf.margin_right=Inches(.08);tf.margin_top=tf.margin_bottom=0
 for i,line in enumerate(txt.split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.alignment=PP_ALIGN.CENTER if center else PP_ALIGN.RIGHT;p.line_spacing=1.12;p.space_after=Pt(0)
  pp=p._p.get_or_add_pPr();pp.set('rtl','1' if re.search('[\u0600-\u06ff]',line) else '0')
  run=p.add_run();run.text=line;run.font.name=FONT;run.font.size=Pt(size);run.font.bold=bold;run.font.color.rgb=RGBColor.from_string(color)
  rp=run._r.get_or_add_rPr();rp.set('lang','ar-SA');cs=OxmlElement('a:cs');cs.set('typeface',FONT);rp.append(cs)
 return sh

def base(title,sub='',n=None,dark=False):
 s=R.slides.add_slide(R.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=RGBColor.from_string(N if dark else W)
 box(s,12.98,0,.35,7.5,G);box(s,.6,1.28,12,.025,G)
 text(s,.7,.28,11.9,.86,title,31,W if dark else N,True)
 if sub:text(s,.78,1.4,11.65,.52,sub,17,'C6DCEB' if dark else M)
 text(s,.75,7.08,10.7,.27,'تطبيقات الحاسوب • المرحلة الثانية | '+AUTHOR,10,'C6DCEB' if dark else M)
 text(s,11.8,7.03,.7,.36,str(len(R.slides)),12,G,center=True)
 MAN.append({'slide':len(R.slides),'lecture':n,'title':title})
 return s

def rows(sl,items,start=2.05,gap=.13,h=1.34):
 for i,(label,body) in enumerate(items):
  y=start+i*(h+gap)
  box(sl,.82,y,11.63,h,P);box(sl,12.37,y,.08,h,G)
  text(sl,9.0,y+.14,3.12,h-.22,label,25,B,True)
  text(sl,1.02,y+.13,7.72,h-.2,body,26)

def bullets(sl,items,start=2.05,h=1.39):
 for i,t in enumerate(items):
  y=start+i*(h+.11);box(sl,.85,y,11.6,h,P);text(sl,1.08,y+.13,10.98,h-.2,t,27)

s=base('تطبيقات الحاسوب','Computer Applications • Second Stage',dark=True)
text(s,1,2.2,11,1.15,'المرحلة الثانية',44,W,True,True)
text(s,1,3.72,11,.9,'إعداد وتدريس: '+AUTHOR,31,W,True,True)
text(s,1,5.22,11,.82,'الإنترنت والبريد • PowerPoint • Excel • Access',26,'C6DCEB',center=True)
s=base('موضوعات المقرر','المعرفة والتطبيق وحل المشكلات')
rows(s,[('01 | الإنترنت','البحث عن المعلومات والمراسلات المهنية.'),('02 | تطبيقات Office','العروض التقديمية، الجداول الإلكترونية، وقواعد البيانات.'),('03 | المشروع','توظيف التطبيقات معًا للإجابة عن سؤال تخصصي.')])
last=None
for i,x in enumerate(L):
 n=i+1
 if x['unit']!=last:
  s=base(x['unit'],'',dark=True)
  text(s,1.0,2.6,11.2,1.45,x['unit'],43,W,True,True)
  text(s,1.0,4.55,11.2,.8,'مفاهيم أساسية • أمثلة محلولة • تطبيقات صفية',27,'C6DCEB',center=True)
  last=x['unit']
 s=base(x['title'],x['en'],n)
 text(s,1,2.1,11.3,.75,f'المحاضرة {n:02d}',29,B,True)
 rows(s,[(str(j+1).zfill(2),o) for j,o in enumerate(x['objectives'])],start=3.02,h=1.07)
 for k,(heading,body) in enumerate(x['sections']):
  s=base(heading,f"{n:02d} | {x['title']}",n)
  rows(s,C[i][k*3:k*3+3])
 s=base(x['title'],'مخطط يوضح الفكرة والعلاقات',n)
 s.shapes.add_picture(str(IMG/f'{x["diagram"]}.png'),Inches(.65),Inches(1.85),width=Inches(12),height=Inches(4.96))
 s=base(x['example'][0],'مثال محلول',n)
 given,steps,result=EX[i]
 box(s,.85,1.98,11.58,.85,N);text(s,1.05,2.06,11.15,.66,given,25,W)
 for j,step in enumerate(steps):
  y=3.02+j*.89
  box(s,11.68,y,.64,.63,B);text(s,11.73,y+.03,.53,.55,str(j+1),25,W,True,True)
  text(s,1.0,y,10.4,.79,step,27)
 box(s,.85,5.89,11.58,.94,P);text(s,1.03,5.98,11.19,.76,result,25,B,True)
 for part in range(2):
  s=base('التطبيق العملي — '+('الخطوات الأولى' if part==0 else 'إكمال التطبيق'),f"{n:02d} | {x['title']}",n)
  rows(s,[(str(j+1),x['steps'][j]) for j in range(part*3,min(part*3+3,len(x['steps'])))])
 s=base('اختبر فهمك',x['title'],n)
 bullets(s,[q for q,a in x['qa']])
 s=base('الإجابة والتفسير',x['title'],n)
 bullets(s,[a.replace('المدرس','مقدّم العرض') for q,a in x['qa']])
R.save(ROOT/'Computer_Applications_Stage2_Lectures.pptx')
(ROOT/'source/student_slide_manifest.json').write_text(json.dumps(MAN,ensure_ascii=False,indent=2))
(ROOT/'source/student_text_measurements.json').write_text(json.dumps(MEASURES,ensure_ascii=False,indent=2))
print('Student-facing slides:',len(R.slides))
print('Estimated overflow:',[v for v in MEASURES if v['size']>=23 and v['estimated']>v['height']+.1][:20])
# Confirm removal of teacher-facing wrapper and notes.
visible='\n'.join(sh.text for s in R.slides for sh in s.shapes if sh.has_text_frame)
for phrase in ['كيف نستخدم هذا العرض','المدرس','اختبر أوامر المختبر على النسخة','الملزمة','قارن منطق إجابتك']:
 assert phrase not in visible,phrase
assert all(not s.has_notes_slide for s in R.slides)
print('No instructor directions or notes; all 24 lectures present.')
