from pathlib import Path
import re,json
from lxml import html as LH
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from pptx import Presentation
from pptx.util import Inches,Pt as PPt
from pptx.dml.color import RGBColor as PC
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement as PX
from content import L,AUTHOR
ROOT=Path(__file__).resolve().parents[1];IMG=ROOT/'Computer_Applications_Stage2_Images'
NAVY='142D4E';BLUE='2878AC';GOLD='B99445';PALE='EDF5FA';GRAY='506780'
FONT='Noto Sans Arabic';BOOKFONT='Noto Naskh Arabic'
def bidi(p):
 pPr=p._p.get_or_add_pPr();el=OxmlElement('w:bidi');el.set(qn('w:val'),'1');pPr.append(el)
def fmt_run(r,size=12,bold=False,color=NAVY):
 r.font.name=BOOKFONT;r.font.size=Pt(size);r.bold=bold;r.font.color.rgb=RGBColor.from_string(color)
 rp=r._element.get_or_add_rPr();rf=rp.rFonts
 if rf is None:rf=OxmlElement('w:rFonts');rp.insert(0,rf)
 for attr in ['ascii','hAnsi','cs','eastAsia']:rf.set(qn('w:'+attr),BOOKFONT)
 cs=OxmlElement('w:szCs');cs.set(qn('w:val'),str(size*2));rp.append(cs)
 rtl=OxmlElement('w:rtl');rtl.set(qn('w:val'),'1' if re.search('[\u0600-\u06ff]',r.text) else '0');rp.append(rtl)
def para(parent,s,size=12,bold=False,color=NAVY,align=None):
 p=parent.add_paragraph();bidi(p);p.alignment=align or WD_ALIGN_PARAGRAPH.RIGHT
 p.paragraph_format.line_spacing=1.08;p.paragraph_format.space_after=Pt(3)
 fmt_run(p.add_run(s),size,bold,color);return p
D=Document();sec=D.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.top_margin=Cm(1.7);sec.bottom_margin=Cm(1.65);sec.left_margin=sec.right_margin=Cm(1.7)
normal=D.styles['Normal'];normal.font.name=BOOKFONT;normal.font.size=Pt(12)
header=sec.header.paragraphs[0];bidi(header);fmt_run(header.add_run('تطبيقات الحاسوب • المرحلة الثانية     |     '+AUTHOR),9,color=GRAY)
f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.CENTER;fmt_run(f.add_run('Computer Applications • '),9)
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');f._p.append(fld)
D.core_properties.title='تطبيقات الحاسوب — المرحلة الثانية';D.core_properties.author=AUTHOR;D.core_properties.subject='ملزمة جامعية ومحاضرات عملية'
root=LH.fromstring((ROOT/'source/book.html').read_text())
def render(node,parent=D):
 tag=node.tag
 if tag in ['h1','h2','h3','p']:
  size={'h1':19,'h2':14,'h3':12.5,'p':12}[tag]
  s=node.text_content()
  if 'تشير خانة الصفحة' in s:s='التسلسل موحد بين الملزمة والعرض. أرقام الفهرس تشير إلى PDF المرفق؛ قد تختلف صفحات Word بعد التحرير.'
  p=para(parent,s,size,tag!='p',BLUE if tag=='h2' else NAVY)
  if tag.startswith('h'):p.paragraph_format.keep_with_next=True;p.paragraph_format.space_before=Pt(7)
 elif tag in ['ul','ol']:
  for i,li in enumerate(node):para(parent,('• ' if tag=='ul' else str(i+1)+'. ')+li.text_content(),11.5)
 elif tag=='table':
  rows=node.xpath('.//tr');cols=len(rows[0]);t=parent.add_table(rows=0,cols=cols);t.autofit=False
  pr=t._tbl.tblPr;vis=OxmlElement('w:bidiVisual');pr.append(vis)
  widths=([2.2,3.0,10.6,1.8] if cols==4 and 'المفردات الظاهرة' in node.text_content() else ([1.2,7.0,8.0,1.4] if cols==4 else [17.6/cols]*cols))
  for ci,wi in enumerate(widths):t.columns[ci].width=Cm(wi)
  for ri,row in enumerate(rows):
   cells=t.add_row().cells
   for ci,(cell,src) in enumerate(zip(cells,row)):
    cell.width=Cm(widths[ci])
    p=cell.paragraphs[0];bidi(p);p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1.12
    fmt_run(p.add_run(src.text_content()),9,ri==0,'FFFFFF' if ri==0 else NAVY)
    if ri==0:
     sh=OxmlElement('w:shd');sh.set(qn('w:fill'),NAVY);cell._tc.get_or_add_tcPr().append(sh)
   trpr=t.rows[-1]._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
  parent.add_paragraph()
 elif tag=='figure':
  name=Path(node.xpath('.//img')[0].get('src')).stem
  p=parent.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run().add_picture(str(IMG/f'{name}.png'),width=Cm(14.4))
  caps=node.xpath('.//figcaption');
  if caps:para(parent,caps[0].text_content(),9,color=GRAY,align=WD_ALIGN_PARAGRAPH.CENTER)
 elif tag not in ['img','figcaption']:
  if node.text and node.text.strip():para(parent,node.text.strip(),13)
  for child in node:render(child,parent)
for i,pg in enumerate(root.xpath('//section')):
 if i:D.add_page_break()
 for child in pg.xpath('./div[@class="pagebody"]')[0]:render(child)
D.save(ROOT/'Computer_Applications_Stage2_Editable.docx')
print('DOCX saved')
# ---------------- PowerPoint ----------------
R=Presentation();R.slide_width=Inches(13.333);R.slide_height=Inches(7.5)
R.core_properties.author=AUTHOR;R.core_properties.title='تطبيقات الحاسوب — المرحلة الثانية'
SLIDE_MANIFEST=[]
def tb(sl,x,y,w,h,text,size=26,color=NAVY,bold=False,align=PP_ALIGN.RIGHT):
 sh=sl.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h));tf=sh.text_frame;tf.clear();tf.word_wrap=True;tf.vertical_anchor=MSO_ANCHOR.TOP;tf.margin_left=tf.margin_right=Inches(.08);tf.margin_top=Inches(.02);tf.margin_bottom=0
 for i,line in enumerate(text.split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.alignment=align;p.font.name=FONT;p.font.size=PPt(size);p.font.bold=bold;p.font.color.rgb=PC.from_string(color);p.space_after=PPt(9);p.line_spacing=1.18
  pPr=p._p.get_or_add_pPr();pPr.set('rtl','1' if re.search('[\u0600-\u06ff]',line) else '0')
  r=p.add_run();r.text=line;r.font.name=FONT;r.font.size=PPt(size);r.font.bold=bold;r.font.color.rgb=PC.from_string(color)
  rp=r._r.get_or_add_rPr();rp.set('lang','ar-SA');cs=PX('a:cs');cs.set('typeface',FONT);rp.append(cs)
 return sh
def base(title,sub='',lecture=None):
 s=R.slides.add_slide(R.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=PC.from_string('FFFFFF')
 band=s.shapes.add_shape(1,0,0,R.slide_width,Inches(.14));band.fill.solid();band.fill.fore_color.rgb=PC.from_string(GOLD);band.line.fill.background()
 tb(s,.55,.31,12.2,.95,title,28,bold=True)
 if sub:tb(s,.7,1.12,11.9,.6,sub,16,GRAY)
 tb(s,.65,7.06,10,.27,'تطبيقات الحاسوب • المرحلة الثانية | '+AUTHOR,10,GRAY)
 tb(s,11.8,7.01,.8,.35,str(len(R.slides)),12,GOLD,align=PP_ALIGN.CENTER)
 SLIDE_MANIFEST.append({'slide':len(R.slides),'title':title,'lecture':lecture})
 return s
def bullets(sl,items,y=1.8,size=27):
 from PIL import ImageFont
 fontpath='/usr/share/fonts/truetype/noto/NotoSansArabic-Regular.ttf'
 def heights_at(sz):
  font=ImageFont.truetype(fontpath,round(sz*96/72))
  out=[]
  for item in items:
   lines=1;line=''
   for word in ('• '+item).split():
    test=line+' '+word
    if font.getlength(test)>1080 and line:lines+=1;line=word
    else:line=test
   out.append(lines*sz/72*1.68+.12)
  return out
 heights=heights_at(size)
 while sum(heights)>6.87-y and size>21:
  size-=1;heights=heights_at(size)
 for item,h in zip(items,heights):
  tb(sl,.85,y,11.6,h,'• '+item,size);y+=h
s=base('تطبيقات الحاسوب','Computer Applications • Second Stage')
tb(s,1,2,11.3,1.2,'ملزمة ومحاضرات مترابطة\nالمرحلة الثانية',36,bold=True)
tb(s,1,3.6,11.3,1.2,'إعداد وتدريس: '+AUTHOR,32,BLUE)
tb(s,1,5.15,11.3,1.15,'Microsoft 365 / Office 2024\nرسوم أصلية تخطيطية • نوفمبر 2026',23,GRAY)
s=base('خريطة المقرر','24 محاضرة • تسلسل مطابق للملزمة')
bullets(s,['الإنترنت والبريد الإلكتروني: المحاضرات 1–3','PowerPoint: المحاضرات 4–7','Excel: المحاضرات 8–17','Access: المحاضرات 18–22','المشروعات حسب التخصص: المحاضرتان 23–24'])
s=base('كيف نستخدم هذا العرض؟','الشرح التفصيلي والأجوبة في الملزمة')
bullets(s,['ابدأ بالسؤال الواقعي، ثم اقرأ الرسم ونفّذ المثال.','اختبر النتيجة على مدخلات جديدة قبل الانتقال.','الواجهات هنا مخططات إرشادية وليست لقطات برامج حقيقية.','قد تختلف أسماء الأوامر حسب النسخة واللغة.','Access يتطلب نسخة سطح مكتب Windows المناسبة.'])
last=None
for x in L:
 n=x['n']
 if x['unit']!=last:
  s=base(x['unit'],'وحدة تعليمية • مفاهيم ثم مختبر وتحقق');tb(s,1.2,2.6,10.9,2,x['unit'],44,BLUE,True);last=x['unit']
 s=base(f"{n:02d} | {x['title']}",x['en'],n);bullets(s,x['objectives']+[x['intro']],size=26)
 for title,body in x['sections']:
  s=base(title,f"المحاضرة {n} • {x['title']}",n)
  items=[]
  for para_ in body.split('\n'):
   sentences=re.split(r'(?<=[.؟])\s+',para_)
   # Preserve concepts and actionable details in concise, complete sentences.
   if len(sentences)>2:items.extend([sentences[0],sentences[-1]])
   else:items.append(para_)
  bullets(s,items,size=26)
  s.notes_slide.notes_text_frame.text=title+'\n'+body
 s=base('اقرأ الرسم واشرح العلاقة',f"المحاضرة {n} • {x['title']}",n)
 s.shapes.add_picture(str(IMG/f'{x["diagram"]}.png'),Inches(.55),Inches(1.48),width=Inches(12.2),height=Inches(5.47))
 s.notes_slide.notes_text_frame.text=x['sections'][0][1]
 s=base('مختبر: نفّذ ثم تحقق',f"المحاضرة {n} • خطوات العمل",n);bullets(s,[str(i+1)+'. '+z for i,z in enumerate(x['steps'])],size=25)
 s=base(x['example'][0],f"المحاضرة {n} • مثال محلول",n)
 example=x['example'][1];parts=re.split(r'(?<=[.؟])\s+',example)
 bullets(s,parts,size=26);s.notes_slide.notes_text_frame.text=example
 s=base('خلاصة وأسئلة للنقاش',f"المحاضرة {n} • الإجابات في القسم الأخير",n)
 bullets(s,[a for a,b in x['sections']]+[q for q,a in x['qa']],size=25)
 s.notes_slide.notes_text_frame.text='ملاحظة: '+x['notes']+'\nأخطاء شائعة: '+x['mistakes']
s=base('الإجابات النموذجية','قسم منفصل — استخدمه بعد محاولة الإجابة')
bullets(s,['قارن منطق إجابتك بالجواب، لا الصياغة وحدها.','اختبر أوامر المختبر على النسخة المتاحة في المؤسسة.','تتضمن الملزمة ملاحظات وأخطاء شائعة ومفردات المنهج كاملة.'])
for x in L:
 s=base(f"أجوبة المحاضرة {x['n']}",x['title'],x['n']);bullets(s,[str(i+1)+'. '+a for i,(q,a) in enumerate(x['qa'])],size=27)
 s.notes_slide.notes_text_frame.text='\n'.join(q+'\n'+a for q,a in x['qa'])
s=base('المشروع الختامي: ماذا نسلّم؟','الدقة وإمكان إعادة النتائج هما معيار النجاح')
bullets(s,['قاعدة بيانات بمفاتيح وعلاقات وقاموس بيانات.','مصنف يحوي صيغًا وتحليلًا ورسمًا ومجاميع مطابقة.','عرض يشرح السؤال والطريقة والنتيجة والحدود.','سجل اختبارات وحزمة منظمة ورسالة تسليم مهنية.','التقييم: المتطلبات 15، القاعدة 25، التحليل 25، العرض 15، الاختبار 15، التسليم 5.'])
R.save(ROOT/'Computer_Applications_Stage2_Lectures.pptx')
(ROOT/'source/slide_manifest.json').write_text(json.dumps(SLIDE_MANIFEST,ensure_ascii=False,indent=2))
print('PPTX slides:',len(R.slides))
