from pathlib import Path
import re,json
from lxml import html as LH
from docx import Document
from docx.shared import Pt,Cm,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from pptx import Presentation
from pptx.util import Inches,Pt as PPt
from pptx.dml.color import RGBColor as PC
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement as PX
from content import L,AUTHOR
ROOT=Path(__file__).resolve().parents[1];IMG=ROOT/'Computer_Applications_Stage2_Images'
NAVY='142D4E';BLUE='2878AC';GOLD='B99445';PALE='EDF5FA';GRAY='506780'
FONT='Noto Sans Arabic';BOOKFONT='Noto Naskh Arabic'
def bidi(p):
 pPr=p._p.get_or_add_pPr();el=OxmlElement('w:bidi');el.set(qn('w:val'),'1');pPr.append(el)
def fmt_run(r,size=12,bold=False,color=NAVY):
 r.font.name=BOOKFONT;r.font.size=Pt(size);r.bold=bold;r.font.color.rgb=RGBColor.from_string(color)
 rp=r._element.get_or_add_rPr();rf=rp.rFonts
 if rf is None:rf=OxmlElement('w:rFonts');rp.insert(0,rf)
 for attr in ['ascii','hAnsi','cs','eastAsia']:rf.set(qn('w:'+attr),BOOKFONT)
 cs=OxmlElement('w:szCs');cs.set(qn('w:val'),str(size*2));rp.append(cs)
 rtl=OxmlElement('w:rtl');rtl.set(qn('w:val'),'1' if re.search('[\u0600-\u06ff]',r.text) else '0');rp.append(rtl)
def para(parent,s,size=12,bold=False,color=NAVY,align=None):
 p=parent.add_paragraph();bidi(p);p.alignment=align or WD_ALIGN_PARAGRAPH.RIGHT
 p.paragraph_format.line_spacing=1.08;p.paragraph_format.space_after=Pt(3)
 fmt_run(p.add_run(s),size,bold,color);return p
D=Document();sec=D.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.top_margin=Cm(1.7);sec.bottom_margin=Cm(1.65);sec.left_margin=sec.right_margin=Cm(1.7)
normal=D.styles['Normal'];normal.font.name=BOOKFONT;normal.font.size=Pt(12)
header=sec.header.paragraphs[0];bidi(header);fmt_run(header.add_run('تطبيقات الحاسوب • المرحلة الثانية     |     '+AUTHOR),9,color=GRAY)
f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.CENTER;fmt_run(f.add_run('Computer Applications • '),9)
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');f._p.append(fld)
D.core_properties.title='تطبيقات الحاسوب — المرحلة الثانية';D.core_properties.author=AUTHOR;D.core_properties.subject='ملزمة جامعية ومحاضرات عملية'
root=LH.fromstring((ROOT/'source/book.html').read_text())
def render(node,parent=D):
 tag=node.tag
 if tag in ['h1','h2','h3','p']:
  size={'h1':19,'h2':14,'h3':12.5,'p':12}[tag]
  s=node.text_content()
  if 'تشير خانة الصفحة' in s:s='التسلسل موحد بين الملزمة والعرض. أرقام الفهرس تشير إلى PDF المرفق؛ قد تختلف صفحات Word بعد التحرير.'
  p=para(parent,s,size,tag!='p',BLUE if tag=='h2' else NAVY)
  if tag.startswith('h'):p.paragraph_format.keep_with_next=True;p.paragraph_format.space_before=Pt(7)
 elif tag in ['ul','ol']:
  for i,li in enumerate(node):para(parent,('• ' if tag=='ul' else str(i+1)+'. ')+li.text_content(),11.5)
 elif tag=='table':
  rows=node.xpath('.//tr');cols=len(rows[0]);t=parent.add_table(rows=0,cols=cols);t.autofit=False
  pr=t._tbl.tblPr;vis=OxmlElement('w:bidiVisual');pr.append(vis)
  widths=([2.2,3.0,10.6,1.8] if cols==4 and 'المفردات الظاهرة' in node.text_content() else ([1.2,7.0,8.0,1.4] if cols==4 else [17.6/cols]*cols))
  for ci,wi in enumerate(widths):t.columns[ci].width=Cm(wi)
  for ri,row in enumerate(rows):
   cells=t.add_row().cells
   for ci,(cell,src) in enumerate(zip(cells,row)):
    cell.width=Cm(widths[ci])
    p=cell.paragraphs[0];bidi(p);p.alignment=WD_ALIGN_PARAGRAPH.RIGHT;p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1.12
    fmt_run(p.add_run(src.text_content()),9,ri==0,'FFFFFF' if ri==0 else NAVY)
    if ri==0:
     sh=OxmlElement('w:shd');sh.set(qn('w:fill'),NAVY);cell._tc.get_or_add_tcPr().append(sh)
   trpr=t.rows[-1]._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
  parent.add_paragraph()
 elif tag=='figure':
  name=Path(node.xpath('.//img')[0].get('src')).stem
  p=parent.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run().add_picture(str(IMG/f'{name}.png'),width=Cm(14.4))
  caps=node.xpath('.//figcaption');
  if caps:para(parent,caps[0].text_content(),9,color=GRAY,align=WD_ALIGN_PARAGRAPH.CENTER)
 elif tag not in ['img','figcaption']:
  if node.text and node.text.strip():para(parent,node.text.strip(),13)
  for child in node:render(child,parent)
for i,pg in enumerate(root.xpath('//section')):
 if i:D.add_page_break()
 for child in pg.xpath('./div[@class="pagebody"]')[0]:render(child)
D.save(ROOT/'Computer_Applications_Stage2_Editable.docx')
print('DOCX saved')
# Student-facing lecture deck (no instructor wrapper or notes).
import runpy
runpy.run_path(str(ROOT/'source/student_deck.py'),run_name='__main__')
